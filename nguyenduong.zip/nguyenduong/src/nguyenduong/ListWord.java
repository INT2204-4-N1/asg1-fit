package nguyenduong;

//import nguyenduong.DataDictionary.DataDictionarySQL;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;

public class ListWord implements ListSelectionListener {
    private static JList list  = new JList();
    private JScrollPane Scroll = new JScrollPane(list) ;

    public ListWord(){
        list.setBounds(15,65,255,550);
        list.setFont(new Font(Font.DIALOG,Font.BOLD,16));
        Scroll.setBounds(15,65,255,550);
        list.addListSelectionListener(this);

        Dictionary.getFrame().add(Scroll);
    }
    public static void UpdateList(){
        String w = InputApp.getTextInput().getText();
        if(w.equals("")){
            list.setListData(new String[]{""});
        }
        else {
            String listWord[] = DataDictionarySQL.ListWord(w);
            list.setListData(listWord);
        }
    }
    @Override
    public void valueChanged(ListSelectionEvent e) {
        if(list.getSelectedIndex() != -1){
            InputApp.getTextInput().setText((String) list.getSelectedValue());
            OutputApp.getOutputApp().setText(DataDictionarySQL.SearchAnhViet((String) list.getSelectedValue()));
        }
    }
}
